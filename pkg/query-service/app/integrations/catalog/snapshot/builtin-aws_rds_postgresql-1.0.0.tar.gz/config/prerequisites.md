## Before You Begin  

To configure metrics and logs collection for an AWS RDS for PostgreSQL, you need the following.

- **Ensure Credentials and permissions are set correctly**  
 The components used for this integration rely on AWS SDKs, which offer a variety of ways to provide credentials, including the `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` environment variables.  
 The following IAM permissions are required:
    - `cloudwatch:ListMetrics`
    - `cloudwatch:GetMetricStatistics`
    - `cloudwatch:GetMetricData`
    - `logs:DescribeLogGroups`
    - `logs:FilterLogEvents`

- **Ensure Java Runtime Environment (JRE), version 11 or newer**  
 The CloudWatch Exporter used to collect the metrics requires a Java runtime environment version 11 or newer. Alternatively, you can also run a docker container https://github.com/prometheus/cloudwatch_exporter#docker-images

- **Ensure that an OTEL collector is running in your deployment environment**  
 Please [install an OTEL Collector](https://opentelemetry.io/docs/collector/installation/) If already installed, ensure that the collector version is v0.88.0 or newer. Also, ensure that you can provide config files to the collector and that you can set environment variables and command line flags used for running it.


- **Ensure that the OTEL collector can access the Postgres server**
 To collect Postgres server metrics, the collector must be able to access the Postgres server as a client. This step is optional if you are only interested in working with CloudWatch metrics.
